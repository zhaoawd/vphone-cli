import AppKit
import Foundation

// MARK: - Menu Controller

@MainActor
class VPhoneMenuController {
    let keyHelper: VPhoneKeyHelper
    let control: VPhoneControl
    weak var vm: VPhoneVirtualMachine?

    var onStop: (() -> Void)?
    var onManualUnlock: (() -> Void)?
    var onStartupUnlockChanged: ((Bool) throws -> Void)?
    var startupUnlockItem: NSMenuItem?
    var manualUnlockItem: NSMenuItem?
    var onFilesPressed: (() -> Void)?
    var onKeychainPressed: (() -> Void)?
    var onAppsPressed: (() -> Void)?
    var connectFileBrowserItem: NSMenuItem?
    var connectKeychainBrowserItem: NSMenuItem?
    var connectDevModeStatusItem: NSMenuItem?
    var connectPingItem: NSMenuItem?
    var connectGuestVersionItem: NSMenuItem?
    var connectShellItem: NSMenuItem?
    var installPackageItem: NSMenuItem?
    var clipboardGetItem: NSMenuItem?
    var clipboardSetItem: NSMenuItem?
    var appsListItem: NSMenuItem?
    var appsOpenURLItem: NSMenuItem?
    var settingsGetItem: NSMenuItem?
    var settingsSetItem: NSMenuItem?
    var touchIDMonitor: VPhoneTouchIDMonitor? {
        didSet { touchIDMonitor?.isEnabled = touchIDMenuItem?.state == .on }
    }
    var touchIDMenuItem: NSMenuItem?
    var locationProvider: VPhoneLocationProvider?
    var locationMenuItem: NSMenuItem?
    var locationPresetMenuItem: NSMenuItem?
    var locationReplayStartItem: NSMenuItem?
    var locationReplayStopItem: NSMenuItem?
    var screenRecorder: VPhoneScreenRecorder?
    var recordingItem: NSMenuItem?
    var cameraServer: VPhoneCameraServer?
    var cameraStatusItem: NSMenuItem?
    var cameraSourceOffItem: NSMenuItem?
    var cameraSourceTestPatternItem: NSMenuItem?
    var cameraSourceVideoFileItem: NSMenuItem?
    var cameraStartStopItem: NSMenuItem?
    weak var captureView: VPhoneVirtualMachineView?
    var batterySyncEnabled = false
    var batterySyncStatusItem: NSMenuItem?
    var batteryLevelMenuItems: [NSMenuItem] = []
    var batteryConnectivityMenuItems: [NSMenuItem] = []
    var powerSourceRunLoopSource: CFRunLoopSource?
    var powerSourceRetainedPtr: UnsafeMutableRawPointer?
    var lowPowerObserver: (any NSObjectProtocol)?

    init(keyHelper: VPhoneKeyHelper, control: VPhoneControl) {
        self.keyHelper = keyHelper
        self.control = control
        setupMenuBar()
    }

    // MARK: - Menu Bar Setup

    private func setupMenuBar() {
        let mainMenu = NSMenu()

        // App menu
        let appMenuItem = NSMenuItem()
        let appMenu = NSMenu(title: "vphone")
        #if canImport(VPhoneBuildInfo)
            let buildItem = NSMenuItem(
                title: "Build: \(VPhoneBuildInfo.commitHash)", action: nil, keyEquivalent: ""
            )
        #else
            let buildItem = NSMenuItem(title: "Build: unknown", action: nil, keyEquivalent: "")
        #endif
        buildItem.isEnabled = false
        appMenu.addItem(buildItem)
        appMenu.addItem(NSMenuItem.separator())
        appMenu.addItem(makeItem("Stop VM", action: #selector(stopVM)))
        let manual = makeItem("Unlock Screen…", action: #selector(unlockScreen))
        manual.isEnabled = false
        manualUnlockItem = manual
        appMenu.addItem(manual)
        let startup = makeItem("Unlock at Startup", action: #selector(toggleStartupUnlock))
        startup.isEnabled = false
        startupUnlockItem = startup
        appMenu.addItem(startup)
        appMenu.addItem(
            withTitle: "Quit vphone", action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q"
        )
        appMenuItem.submenu = appMenu
        mainMenu.addItem(appMenuItem)

        mainMenu.addItem(buildConnectMenu())
        mainMenu.addItem(buildKeysMenu())
        mainMenu.addItem(buildAppsMenu())
        mainMenu.addItem(buildRecordMenu())

        // Window menu — provides Cmd+W (close) and Cmd+M (minimize) for any key window
        let windowMenuItem = NSMenuItem()
        let windowMenu = NSMenu(title: "Window")
        windowMenu.addItem(
            withTitle: "Close", action: #selector(NSWindow.performClose(_:)), keyEquivalent: "w"
        )
        windowMenu.addItem(
            withTitle: "Minimize", action: #selector(NSWindow.performMiniaturize(_:)), keyEquivalent: "m"
        )
        windowMenuItem.submenu = windowMenu
        mainMenu.addItem(windowMenuItem)
        NSApp.windowsMenu = windowMenu

        NSApp.mainMenu = mainMenu
    }

    func makeItem(_ title: String, action: Selector) -> NSMenuItem {
        let item = NSMenuItem(title: title, action: action, keyEquivalent: "")
        item.target = self
        return item
    }
}

extension VPhoneMenuController {
    @objc private func stopVM() { onStop?() }
    @objc private func unlockScreen() { onManualUnlock?() }
    @objc private func toggleStartupUnlock() {
        guard let item = startupUnlockItem, let change = onStartupUnlockChanged else { return }
        let enabled = item.state != .on
        do { try change(enabled); item.state = enabled ? .on : .off }
        catch { let alert = NSAlert(); alert.messageText = "Unable to save startup unlock"; alert.informativeText = error.localizedDescription; alert.runModal() }
    }
}
