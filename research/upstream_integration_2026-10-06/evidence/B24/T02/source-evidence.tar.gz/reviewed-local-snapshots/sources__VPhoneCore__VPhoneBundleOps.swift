import Darwin
import Foundation
import VPhoneArchiveKit

public enum VPhoneBundleOpsError: Error, Equatable {
    case tarFailed(String)
    case badArchive(String)
}

/// The unit of `--disk-size`, the Launchpad stepper and every disk size the
/// CLI and Launchpad display. `create` makes N × 2^30 bytes; displays divide
/// by the same unit so the number shown is the number given at creation.
///
/// Upstream 6a8d2c7 creates N × 10^9 bytes and displays bytes / 10^9 (the unit
/// iOS reports). Adopting it changes the bytes of new disks, which T14 did
/// not do; until then, dividing by 10^9 would show a 64 disk as 68.
public enum VPhoneDiskSize {
    public static let bytesPerGB: UInt64 = 1 << 30

    public static func bytes(gigabytes: UInt64) -> UInt64 {
        gigabytes * bytesPerGB
    }

    /// Whole units, rounded down, for display.
    public static func gigabytes(bytes: Int64) -> Int64 {
        bytes / Int64(bytesPerGB)
    }
}

public enum VPhoneBundleOps {
    public struct NewBundleSpec: Sendable {
        public var name: String
        public var cpuCount: UInt
        public var memoryMB: UInt64
        public var diskSizeGB: UInt64
        public var romSource: URL
        public var sepromSource: URL

        public init(name: String, cpuCount: UInt, memoryMB: UInt64, diskSizeGB: UInt64,
                    romSource: URL, sepromSource: URL) {
            self.name = name; self.cpuCount = cpuCount; self.memoryMB = memoryMB
            self.diskSizeGB = diskSizeGB; self.romSource = romSource; self.sepromSource = sepromSource
        }
    }

    private static let frameworkResources = URL(fileURLWithPath:
        "/System/Library/Frameworks/Virtualization.framework/Versions/A/Resources")

    public static func defaultROMSource() -> URL {
        frameworkResources.appendingPathComponent("AVPBooter.vresearch1.bin")
    }
    public static func defaultSEPROMSource() -> URL {
        frameworkResources.appendingPathComponent("AVPSEPBooter.vresearch1.bin")
    }

    private static func requireValidName(_ name: String) throws {
        guard !name.isEmpty, !name.contains("/"), !name.hasPrefix(".") else {
            throw VPhoneLibraryError.invalidName(name)
        }
    }

    public static func create(_ spec: NewBundleSpec, in library: VPhoneLibrary) throws -> VPhoneBundle {
        try create(spec, in: library, afterNameCheck: nil)
    }

    /// The bundle directory does not exist when the name is checked, so there is
    /// nothing to take a bundle lock on: `create` runs under the library-root
    /// lock instead, from the existence check through the last write.
    ///
    /// `afterNameCheck` is a testing seam that runs between the check and the
    /// directory creation, so a test can prove the two are one lock lifetime.
    static func create(
        _ spec: NewBundleSpec, in library: VPhoneLibrary, afterNameCheck: (() -> Void)?
    ) throws -> VPhoneBundle {
        try requireValidName(spec.name)
        let fm = FileManager.default
        let dir = library.url(forName: spec.name)
        return try VPhoneBundleGuard.withLibraryLock(root: library.root) { _ in
            if fm.fileExists(atPath: dir.path) {
                throw VPhoneLibraryError.alreadyExists(name: spec.name)
            }
            afterNameCheck?()
            // No intermediate directories: creating the bundle directory then
            // fails on an existing name instead of adopting it, so the rollback
            // below can only ever remove a directory this call made.
            do {
                try fm.createDirectory(at: dir, withIntermediateDirectories: false)
            } catch let error as NSError
                where error.domain == NSCocoaErrorDomain && error.code == NSFileWriteFileExistsError
            {
                throw VPhoneLibraryError.alreadyExists(name: spec.name)
            }
            // Roll back the partial bundle on any failure after the dir is created,
            // so a retry with the same name isn't permanently blocked by the
            // alreadyExists check.
            do {
                // Sparse disk image: create then truncate to size (no bytes written).
                let disk = dir.appendingPathComponent("Disk.img")
                fm.createFile(atPath: disk.path, contents: nil)
                let handle = try FileHandle(forWritingTo: disk)
                do {
                    try handle.truncate(atOffset: VPhoneDiskSize.bytes(gigabytes: spec.diskSizeGB))
                    try handle.close()
                } catch {
                    try? handle.close()
                    throw error
                }

                // SEP storage: 512 KB of zeros (real bytes, matches vm_create.sh).
                try Data(count: 512 * 1024).write(to: dir.appendingPathComponent("SEPStorage"))

                // ROMs.
                try fm.copyItem(at: spec.romSource, to: dir.appendingPathComponent("AVPBooter.vresearch1.bin"))
                try fm.copyItem(at: spec.sepromSource, to: dir.appendingPathComponent("AVPSEPBooter.vresearch1.bin"))

                // Manifest.
                let manifest = VPhoneVirtualMachineManifest(
                    cpuCount: spec.cpuCount,
                    memorySize: spec.memoryMB * 1024 * 1024,
                    romImages: .init(avpBooter: "AVPBooter.vresearch1.bin",
                                     avpSEPBooter: "AVPSEPBooter.vresearch1.bin"))
                try manifest.write(to: dir.appendingPathComponent("config.plist"))

                return VPhoneBundle(url: dir, manifest: manifest)
            } catch {
                try? fm.removeItem(at: dir)
                throw error
            }
        }
    }

    // MARK: - Config editing

    public static func updateConfig(
        bundleNamed name: String, in library: VPhoneLibrary,
        cpuCount: UInt?, memoryMB: UInt64?,
        networkMode: VPhoneVirtualMachineManifest.NetworkConfig.NetworkMode? = nil,
        bridgeInterface: String? = nil,
        hardwareKeyboardEnabled: Bool? = nil,
        unlockAtStartup: Bool? = nil
    ) throws -> VPhoneBundle {
        let directory = try library.bundle(named: name).url
        // Editing the config of a running VM is refused, not queued: the boot
        // process read the manifest at start and would not see the change.
        return try VPhoneBundleGuard.withBundleLock(
            directory: directory, operation: VPhoneVMOperation.config
        ) { _ in
            let bundle = try library.bundle(named: name)
            let editsNetwork = networkMode != nil || bridgeInterface != nil
            let network = editsNetwork
                ? try VPhoneNetworking.merge(
                    into: bundle.manifest.networkConfig,
                    mode: networkMode, bridgeInterface: bridgeInterface)
                : nil
            let updated = bundle.manifest.updating(
                cpuCount: cpuCount,
                memorySize: memoryMB.map { $0 * 1024 * 1024 },
                screenConfig: nil,
                networkConfig: network,
                hardwareKeyboardEnabled: hardwareKeyboardEnabled,
                unlockAtStartup: unlockAtStartup)
            try updated.write(to: bundle.configURL)
            return VPhoneBundle(url: bundle.url, manifest: updated)
        }
    }

    // MARK: - Rename / delete

    public static func rename(
        bundleNamed name: String, to newName: String, in library: VPhoneLibrary
    ) throws -> VPhoneBundle {
        try requireValidName(newName)
        let src = try library.bundle(named: name).url
        return try VPhoneBundleGuard.withBundleLock(
            directory: src, operation: VPhoneVMOperation.rename
        ) { _ in
            let dst = library.url(forName: newName)
            // The destination name is a library-wide resource: the check and the
            // move are one library-lock lifetime, so a concurrent create/import
            // of the same name cannot slip in between them.
            try VPhoneBundleGuard.withLibraryLock(root: library.root) { _ in
                if FileManager.default.fileExists(atPath: dst.path) {
                    throw VPhoneLibraryError.alreadyExists(name: newName)
                }
                try FileManager.default.moveItem(at: src, to: dst)
            }
            // The record written when this lock was taken travelled with the
            // directory and still names the old path. It is diagnostic only and
            // this operation is over, so drop it rather than leave a stale path.
            try? FileManager.default.removeItem(
                at: dst.appendingPathComponent(VPhoneVMRuntimeState.filename))
            return try VPhoneBundle.load(at: dst)
        }
    }

    public static func delete(bundleNamed name: String, in library: VPhoneLibrary) throws {
        let url = try library.bundle(named: name).url
        try VPhoneBundleGuard.withBundleLock(
            directory: url, operation: VPhoneVMOperation.delete
        ) { _ in
            try FileManager.default.removeItem(at: url)
        }
    }

    // MARK: - Clone
    /// Copy a stopped VM's complete persistent boot state, retaining its device
    /// identity (NVRAM, machine identifier, SEP storage and tickets stay together).
    /// This is not a new independent device: use create/restore for that purpose.
    /// Prefer APFS CoW; omit host runtime state, the control socket and CFW rollback history.
    public static func clone(
        bundleNamed name: String, to newName: String, in library: VPhoneLibrary
    ) throws -> VPhoneBundle {
        try clone(bundleNamed: name, to: newName, in: library, copyDirectory: {
            try VPhoneCloneCopy.copy(from: $0, to: $1, excludingRootNames: $2)
        })
    }

    /// Test seams for forced non-APFS copying, failed copies and a destination
    /// collision immediately before publication. No global mutable test hooks.
    static func clone(
        bundleNamed name: String, to newName: String, in library: VPhoneLibrary,
        copyDirectory: (URL, URL, Set<String>) throws -> Void,
        afterNameCheck: (() throws -> Void)? = nil
    ) throws -> VPhoneBundle {
        try requireValidName(newName)
        let src = try library.bundle(named: name).url
        // Keep the existing source lock for the full snapshot and publication.
        // Running VMs remain refused; there is no live-snapshot opt-out.
        return try VPhoneBundleGuard.withBundleLock(
            directory: src, operation: VPhoneVMOperation.clone
        ) { _ in
            let dst = library.url(forName: newName)
            let fm = FileManager.default
            if try VPhoneCloneCopy.exists(at: dst) {
                throw VPhoneLibraryError.alreadyExists(name: newName)
            }
            // Only an exclusively created private directory may be rolled back.
            // Never clean up the final name after a failed clone or EEXIST.
            let staging = library.root.appendingPathComponent(".clone-\(UUID().uuidString)")
            try fm.createDirectory(at: staging, withIntermediateDirectories: false,
                                   attributes: [.posixPermissions: 0o700])
            defer { try? fm.removeItem(at: staging) }
            let payload = staging.appendingPathComponent("payload")
            try copyDirectory(src, payload, [VPhoneVMRuntimeState.filename, "vphone.sock", ".cfw-history"])
            let staged = try VPhoneBundle.load(at: payload)
            // As in importArchive, copying happens privately, then name checking
            // and publication use the library lock. Slow copies do not monopolize it.
            return try VPhoneBundleGuard.withLibraryLock(root: library.root) { _ in
                if try VPhoneCloneCopy.exists(at: dst) {
                    throw VPhoneLibraryError.alreadyExists(name: newName)
                }
                try afterNameCheck?()
                do {
                    try fm.moveItem(at: payload, to: dst)
                } catch let error as NSError
                    where (error.domain == NSCocoaErrorDomain && error.code == NSFileWriteFileExistsError)
                    || (error.domain == NSPOSIXErrorDomain && error.code == Int(EEXIST))
                {
                    throw VPhoneLibraryError.alreadyExists(name: newName)
                }
                return VPhoneBundle(url: dst, manifest: staged.manifest)
            }
        }
    }

    // MARK: - Export / Import

    /// Native transfer remains opt-in until real-VM acceptance is complete.
    public enum ArchiveBackend: String, CaseIterable, Sendable {
        case systemTar = "system-tar"
        case native
    }

    /// Compression preset for `export`. Both import transparently — `importArchive`
    /// auto-detects the compressor when it extracts. `threads=0` → all cores.
    public enum ExportCompression: String, CaseIterable, Sendable {
        case fast, max

        var tarArgs: [String] {
            switch self {
            case .fast: ["--zstd", "--options", "zstd:compression-level=3,zstd:threads=0"]
            case .max:  ["-J", "--options", "xz:compression-level=9,xz:threads=0"]
            }
        }

        /// Extension for auto-named output when `export`'s destination is a directory.
        public var fileExtension: String {
            switch self {
            case .fast: "tzst"
            case .max:  "txz"
            }
        }
    }

    /// Regenerable staging artifacts that never need to travel in an export:
    /// `.vphoned.signed` is re-staged on the next launch, and the CFW install
    /// inputs/temp are consumed at install time (the result already lives in
    /// `Disk.img`). `.cfw_disk.*` holds an unpublished staged disk copy and
    /// `.cfw-history` the host-local CFW transaction records and the previous
    /// Disk.img kept for rollback (T15). Always excluded.
    static let exportExcludePatterns = ["*.vphoned.signed", "*cfw_input*", "*cfw_jb_input*", "*.cfw_temp*", "*.cfw_mount.*",
                                        "*.cfw_disk.*", "*.cfw-history*", "*.vphone-runtime.json"]

    /// When `to` is an existing directory, the archive is written inside it as
    /// `<name>.<compression.fileExtension>`. Returns the resolved output URL.
    ///
    /// The default runs as a two-stage `tar` pipeline (uncompressed producer → compressing
    /// consumer via bsdtar's `@-`) so `progress` can be driven off the
    /// uncompressed byte stream: it is called with `(bytesDone, totalBytes)`,
    /// where `totalBytes` is the bundle's on-disk logical size (minus excludes).
    /// The opt-in native backend packs in process and counts hardlinks once.
    @discardableResult
    public static func export(
        bundleNamed name: String, to outFile: URL, includeIPSW: Bool,
        compression: ExportCompression = .fast, in library: VPhoneLibrary,
        backend: ArchiveBackend = .systemTar,
        progress: ((Int64, Int64) -> Void)? = nil
    ) throws -> URL {
        let bundle = try library.bundle(named: name)
        // Exporting a running VM is refused for the same reason as cloning: the
        // archive would contain a `Disk.img` captured mid-write.
        return try VPhoneBundleGuard.withBundleLock(
            directory: bundle.url, operation: VPhoneVMOperation.export
        ) { _ in
            try exportLocked(
                bundle: bundle, name: name, to: outFile, includeIPSW: includeIPSW,
                compression: compression, in: library, backend: backend, progress: progress)
        }
    }

    private static func exportLocked(
        bundle: VPhoneBundle, name: String, to outFile: URL, includeIPSW: Bool,
        compression: ExportCompression, in library: VPhoneLibrary, backend: ArchiveBackend,
        progress: ((Int64, Int64) -> Void)?
    ) throws -> URL {
        var isDir: ObjCBool = false
        let outFile = FileManager.default.fileExists(atPath: outFile.path, isDirectory: &isDir) && isDir.boolValue
            ? outFile.appendingPathComponent("\(name).\(compression.fileExtension)")
            : outFile

        if backend == .native {
            var excludes = exportExcludePatterns
            if !includeIPSW { excludes.append("*_Restore*") }
            let total = progress == nil ? 0 : VPhoneNativeTransfer.logicalSize(of: bundle.url, excluding: excludes)
            try VPhoneArchiveWriter.create(
                archive: outFile, from: bundle.url, topLevel: name, format: .gnutar,
                compression: compression == .fast ? .zstd(level: 3) : .xz(level: 9),
                excluding: excludes, bytesPacked: { progress?($0, total) })
            progress?(total, total)
            return outFile
        }

        // gnutar (not the bsdtar-default pax): pax extended headers make the
        // consumer's `@-` reader misbid the stream as mtree ("Line too long")
        // on large members; gnutar also carries files >8 GB (ustar cannot).
        var producer = ["--format", "gnutar", "-cf", "-"]
        if !includeIPSW { producer += ["--exclude", "*_Restore*"] }
        for pattern in exportExcludePatterns { producer += ["--exclude", pattern] }
        producer += ["-C", library.root.path, name]
        let consumer = ["-cf", outFile.path] + compression.tarArgs + ["@-"]

        let total = progress != nil
            ? archivedLogicalSize(bundleDir: library.url(forName: name), libraryRoot: library.root, includeIPSW: includeIPSW)
            : 0
        let err = try VPhoneProcessRunner.runCountingTarPipe(
            producerArgs: producer, sourceFile: nil, consumerArgs: consumer
        ) { done in progress?(done, total) }
        if let err { throw VPhoneBundleOpsError.tarFailed(err) }
        return outFile
    }

    /// On-disk logical size of the members `export` will archive, mirroring the
    /// tar `--exclude` patterns so the progress total matches the streamed bytes.
    private static func archivedLogicalSize(
        bundleDir: URL, libraryRoot: URL, includeIPSW: Bool
    ) -> Int64 {
        let fm = FileManager.default
        guard let en = fm.enumerator(
            at: bundleDir,
            includingPropertiesForKeys: [.isRegularFileKey, .fileSizeKey]) else { return 0 }
        let prefix = libraryRoot.path.count + 1  // members are "<name>/..."
        var total: Int64 = 0
        for case let url as URL in en {
            let rel = String(url.path.dropFirst(prefix))
            if !includeIPSW, rel.contains("_Restore") { en.skipDescendants(); continue }
            if exportExcludePatterns.contains(where: { fnmatch($0, rel, 0) == 0 }) { continue }
            guard let vals = try? url.resourceValues(forKeys: [.isRegularFileKey, .fileSizeKey]),
                  vals.isRegularFile == true else { continue }
            total += Int64(vals.fileSize ?? 0)
        }
        return total
    }

    /// Extracts (auto-detecting gzip/zstd/xz) into a private staging dir, then
    /// promotes the single top-level bundle to the library. Extracting first
    /// means the archive is decompressed once; `progress` is called with
    /// `(bytesDone, totalBytes)` as the compressed file is consumed by the backend,
    /// where `totalBytes` is the archive's size on disk.
    public static func importArchive(
        from inFile: URL, name: String?, in library: VPhoneLibrary,
        backend: ArchiveBackend = .systemTar,
        progress: ((Int64, Int64) -> Void)? = nil
    ) throws -> VPhoneBundle {
        try importArchive(from: inFile, name: name, in: library, backend: backend, progress: progress, afterNameCheck: nil)
    }

    /// `afterNameCheck` is a testing seam: it runs between the destination-name
    /// check and the move that places the bundle, which must be one
    /// library-lock lifetime.
    static func importArchive(
        from inFile: URL, name: String?, in library: VPhoneLibrary,
        backend: ArchiveBackend = .systemTar,
        progress: ((Int64, Int64) -> Void)?, afterNameCheck: (() throws -> Void)?
    ) throws -> VPhoneBundle {
        let fm = FileManager.default
        // Fail fast when the destination name is already known (explicit rename).
        if let name {
            try requireValidName(name)
            if try VPhoneCloneCopy.exists(at: library.url(forName: name)) {
                throw VPhoneLibraryError.alreadyExists(name: name)
            }
        }

        // Extract into a private staging dir so the archive's OWN top-level name
        // can never clobber/merge into an existing bundle of that name; only the
        // validated destination name is ever placed into the library.
        try fm.createDirectory(at: library.root, withIntermediateDirectories: true)
        let staging = library.root.appendingPathComponent(".import-\(UUID().uuidString)")
        try fm.createDirectory(at: staging, withIntermediateDirectories: false,
                               attributes: [.posixPermissions: 0o700])
        defer { try? fm.removeItem(at: staging) }
        // An archive may carry a '.' directory header and alter its extraction
        // root's mode. Keep an untouched private parent around that root.
        let contents = staging.appendingPathComponent("contents")
        try fm.createDirectory(at: contents, withIntermediateDirectories: false,
                               attributes: [.posixPermissions: 0o700])

        let total = progress != nil ? fileByteSize(inFile) : 0
        if backend == .native {
            try VPhoneArchiveExtractor.extract(
                inFile, into: contents, options: .intoHostDirectory,
                bytesRead: { progress?(min($0, total), total) })
        } else {
            // Recreate holes from zero blocks, including archives without sparse metadata.
            let err = try VPhoneProcessRunner.runCountingTarPipe(
                producerArgs: nil, sourceFile: inFile, consumerArgs: ["-xSf", "-", "-C", contents.path]
            ) { done in progress?(done, total) }
            if let err { throw VPhoneBundleOpsError.tarFailed(err) }
        }

        let entries = try fm.contentsOfDirectory(atPath: contents.path)
        guard entries.count == 1, let archived = entries.first else {
            throw VPhoneBundleOpsError.badArchive(
                "expected a single top-level bundle directory, found \(entries.sorted())")
        }
        let finalName = name ?? archived
        try requireValidName(finalName)
        let dst = library.url(forName: finalName)
        let extracted = contents.appendingPathComponent(archived)
        guard VPhoneNativeTransfer.fileType(at: extracted) == S_IFDIR,
              VPhoneNativeTransfer.fileType(at: extracted.appendingPathComponent("config.plist")) == S_IFREG else {
            throw VPhoneBundleOpsError.badArchive(
                "archive did not contain a valid bundle (\(archived)/config.plist)")
        }
        // Parse the manifest while the bundle is still in staging: a bundle that
        // fails to load must never occupy its library name.
        let staged = try VPhoneBundle.load(at: extracted)
        try VPhoneNativeTransfer.validate(staged)
        // Extraction ran outside the lock (it only writes into the private
        // staging dir); the name check and the placement are one lock lifetime.
        try VPhoneBundleGuard.withLibraryLock(root: library.root) { _ in
            if try VPhoneCloneCopy.exists(at: dst) { throw VPhoneLibraryError.alreadyExists(name: finalName) }
            try afterNameCheck?()
            guard renamex_np(extracted.path, dst.path, UInt32(RENAME_EXCL)) == 0 else {
                if errno == EEXIST { throw VPhoneLibraryError.alreadyExists(name: finalName) }
                throw POSIXError(POSIXErrorCode(rawValue: errno) ?? .EIO)
            }
        }
        progress?(total, total)
        return VPhoneBundle(url: dst, manifest: staged.manifest)
    }

    private static func fileByteSize(_ url: URL) -> Int64 {
        let size = (try? url.resourceValues(forKeys: [.fileSizeKey]))?.fileSize
        return Int64(size ?? 0)
    }
}
