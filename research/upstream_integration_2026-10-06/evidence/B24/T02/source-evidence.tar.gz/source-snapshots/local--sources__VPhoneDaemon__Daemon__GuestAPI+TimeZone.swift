import Foundation
import IcliKit

// MARK: - Time Zone

/// IcliKit owns the system time zone: tzlinkd moves the
/// `/var/db/timezone/localtime` link for a holder of `com.apple.tzlink.allow`,
/// and a set first turns timed's automatic time zone off through CoreTime,
/// which timed accepts only from a holder of `com.apple.timed`. Each answer is
/// `{identifier, automatic, seconds_from_gmt}`, plus `changed` after a set.
extension GuestAPI {
    static func executeTimeZone(_ method: String, _ params: [String: Any]) throws -> [String: Any]? {
        guard method == "time.timezone" else { return nil }
        if let identifier = optionalString(params, "identifier") {
            return try setTimeZone(identifier)
        }
        if let automatic = params["automatic"] as? Bool {
            return try setAutomaticTimeZone(automatic)
        }
        return try timeZone()
    }
}
