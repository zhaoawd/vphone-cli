import Foundation
import Testing
@testable import VPhoneBundleStore

struct LauncherPolicyTests {
    let target = "/Library/Application Support/vphone-launchpad/Bundles/2.6.1/VPhone.bundle/Contents/MacOS/vphone-cli"

    @Test func permitsOnlyTheStoreCLIAndVMLaunch() throws {
        let request = try VPhoneLaunchpadLauncherRequest(executable: target, arguments: ["vm", "launch", "machine", "--headless"])
        #expect(request.version == "2.6.1")
        #expect(request.arguments == ["vm", "launch", "machine", "--headless"])
    }

    @Test(arguments: ["/usr/bin/true", "/tmp/vphone-cli", "/Library/Application Support/vphone-launchpad/Bundles/2.6.1/../2.6.1/VPhone.bundle/Contents/MacOS/vphone-cli", "/Library/Application Support/vphone-launchpad/Bundles//2.6.1/VPhone.bundle/Contents/MacOS/vphone-cli", "/Library/Application Support/vphone-launchpad/Bundles/2.6.1/VPhone.bundle/Contents/MacOS/vphone-vm"])
    func refusesOtherAndNoncanonicalPaths(path: String) {
        #expect(throws: (any Error).self) { try VPhoneLaunchpadLauncherRequest(executable: path, arguments: ["vm", "launch", "machine"]) }
    }

    @Test(arguments: [[String](), ["vm", "launch"], ["vm", "launch", ""], ["vm", "launch", "--headless"], ["vm", "create", "machine"], ["helper", "register"], ["vm", "launch", "machine", "\0"]])
    func refusesOtherVerbsAndInvalidArguments(arguments: [String]) {
        #expect(throws: (any Error).self) { try VPhoneLaunchpadLauncherRequest(executable: target, arguments: arguments) }
    }

    @Test(arguments: ["2.6.1-local.12345678", "2.6.1-ci.1234567"])
    func permitsValidBuildNames(version: String) throws {
        let path = target.replacingOccurrences(of: "/2.6.1/", with: "/\(version)/")
        #expect(try VPhoneLaunchpadLauncherRequest(executable: path, arguments: ["vm", "launch", "machine"]).version == version)
    }

    @Test func refusesLegacyVersionBeforeFilesystemAccess() {
        #expect(throws: (any Error).self) { try VPhoneLaunchpadLauncherRequest(executable: target.replacingOccurrences(of: "2.6.1", with: "2.0.8"), arguments: ["vm", "launch", "machine"]) }
    }
}
