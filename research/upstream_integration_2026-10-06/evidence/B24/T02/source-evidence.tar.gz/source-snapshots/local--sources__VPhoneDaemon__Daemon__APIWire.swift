import Foundation
import IcliSystem
import NIOCore
import NIOWebSocket

struct APIReply: Sendable {
    let status: Int
    let data: Data

    static func json(status: Int = 200, _ value: [String: Any]) -> APIReply {
        let data = (try? JSONSerialization.data(withJSONObject: value, options: [.sortedKeys]))
            ?? Data(#"{"error":{"code":"serialization_failed","message":"Could not encode response"}}"#.utf8)
        return APIReply(status: status, data: data)
    }
}

enum APIWire {
    static func decode(_ data: Data) throws -> APIRequest {
        try APIRequest.decode(data)
    }

    static func execute(_ request: APIRequest) -> APIReply {
        autoreleasepool { () -> APIReply in
            do {
                let result = try GuestAPI.execute(method: request.method, params: request.params)
                return .json(["type": "response", "id": request.id ?? NSNull(), "result": result])
            } catch {
                let (code, message): (String, String) =
                    if let error = error as? IcliError {
                        (error.code, error.message)
                    } else {
                        (error is GuestAPIError ? "invalid_operation" : "operation_failed", String(describing: error))
                    }
                let details: [String: Any]?
                if let icli = error as? IcliError, case let .commandFailed(output) = icli {
                    details = output
                } else {
                    details = nil
                }
                return .json(status: 400, [
                    "type": "response", "id": request.id ?? NSNull(),
                    "error": GuestOperationFailure.response(code: code, message: message, details: details),
                ])
            }
        }
    }

    static func error(_ message: String, status: Int = 400) -> APIReply {
        .json(status: status, ["error": ["code": "bad_request", "message": message]])
    }
}

/// A client receives guest events on the same WebSocket it uses for commands.
/// Writes are always scheduled on each channel's event loop.
final class APIEventHub: @unchecked Sendable {
    private let lock = NSLock()
    private var channels: [ObjectIdentifier: Channel] = [:]

    func add(_ channel: Channel) {
        lock.lock()
        channels[ObjectIdentifier(channel)] = channel
        lock.unlock()
    }

    func remove(_ channel: Channel) {
        lock.lock()
        channels.removeValue(forKey: ObjectIdentifier(channel))
        lock.unlock()
    }

    func broadcast(name: String, data: [String: Any]) {
        let reply = APIReply.json(["type": "event", "event": name, "data": data])
        lock.lock()
        let recipients = Array(channels.values)
        lock.unlock()
        for channel in recipients {
            channel.eventLoop.execute {
                guard channel.isActive else { return }
                var buffer = channel.allocator.buffer(capacity: reply.data.count)
                buffer.writeBytes(reply.data)
                channel.writeAndFlush(WebSocketFrame(fin: true, opcode: .text, data: buffer), promise: nil)
            }
        }
    }

    var hasSubscribers: Bool {
        lock.lock()
        defer { lock.unlock() }
        return !channels.isEmpty
    }
}
