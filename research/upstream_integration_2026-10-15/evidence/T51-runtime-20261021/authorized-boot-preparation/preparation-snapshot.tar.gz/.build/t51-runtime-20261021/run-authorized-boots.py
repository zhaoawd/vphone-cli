"""Run only the approved T51 candidate and stop its scoped helper afterward."""
from pathlib import Path
import hashlib,json,os,subprocess,time
ROOT=Path(__file__).resolve().parents[2]
WORK=ROOT/'.build/t51-runtime-20261021'
APP=ROOT/'.build/t51-runtime-launchpad-r2-20261021.app'
VM=ROOT/'.build/t51rt/lib/target'
BINARY=APP/'Contents/Helpers/vphone-cli.app/Contents/MacOS/vphone-vm'
CLI=APP/'Contents/Helpers/vphone-cli.app/Contents/MacOS/vphone-cli'
OUT=ROOT/'.build/t51rt/boot-acceptance'
def save(name,value): (WORK/name).write_text(json.dumps(value,indent=2)+'\n')
record=dict(state='preflight',vm=str(VM),cdhash='419d5a6c67ab6328589d27246c5d09eb8cc18312',hostAuthorizationRecorded=True)
try:
    identity=json.loads((WORK/'candidate-identity.json').read_text())
    for key,p in [('vm',BINARY),('cli',CLI)]: assert hashlib.sha256(p.read_bytes()).hexdigest()==identity[key]['sha256']
    helper=json.loads((WORK/'helper-state.json').read_text())
    assert helper['state']=='running' and helper['cdhash']==record['cdhash']
    assert 'Installed validateWithError and isApple breakpoints' in (WORK/'scoped-amfidont-419d5a6c.log').read_text()
    probe=subprocess.run([str(BINARY),'--help'],capture_output=True,text=True,timeout=20)
    save('authorized-parser-probe.json',dict(exitCode=probe.returncode,stdout=probe.stdout,stderr=probe.stderr))
    assert probe.returncode==0, 'approved candidate still cannot parse arguments'
    assert not OUT.exists(), 'fresh boot evidence required'
    record.update(state='booting',helperPID=helper['pid']);save('boot-execution.json',record)
    argv=[str(ROOT/'.venv/bin/python3'),str(ROOT/'research/upstream_integration_2026-10-15/tools/verify_t51_rebase_boot.py'),'--vm',str(VM),'--vm-executable',str(BINARY),'--cli',str(CLI),'--out',str(OUT),'--ready-hold-seconds','35']
    with (WORK/'two-boots.log').open('w') as stream:
        child=subprocess.Popen(argv,stdout=stream,stderr=subprocess.STDOUT)
        record['runnerPID']=child.pid;save('boot-execution.json',record)
        status=child.wait(timeout=600)
    record['exitCode']=status
    assert status==0, 'two-boot regression failed; see two-boots.log'
    result=json.loads((OUT/'runtime-result.json').read_text());assert result['state']=='passed'
    record.update(state='passed',cycles=len(result['cycles']))
except Exception as error:
    record.update(state='failed',error=f'{type(error).__name__}: {error}')
    raise
finally:
    (WORK/'stop-authorized-helper').write_text('Stop only this acceptance helper after the authorized run\n')
    record['helperStopRequestedAt']=time.time();save('boot-execution.json',record)
print(json.dumps(record),flush=True)
