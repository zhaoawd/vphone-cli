#!/usr/bin/env python3
"""Run the installed amfidont for the one explicitly authorized VM CDHash."""
import os
import signal
import threading
import time
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/Users/kolar/github/vphone-cli')
CDHASH = '419d5a6c67ab6328589d27246c5d09eb8cc18312'

if os.geteuid() != 0:
    raise SystemExit('Native administrator authentication is required')
if sys.argv[1:] == ['--worker']:
    sys.path.insert(0, '/Users/kolar/Library/Python/3.9/lib/python/site-packages')
    from amfidont import bypass_runtime
    work = ROOT / '.build/t51-runtime-20261021'
    state = work / 'helper-state.json'
    release = work / 'stop-authorized-helper'
    if release.exists():
        raise SystemExit('Stop marker already exists; no helper started')
    started = time.time()
    record = dict(pid=os.getpid(), cdhash=CDHASH, startedAt=started, maxSeconds=900, state='starting')
    state.write_text(json.dumps(record, indent=2) + '\n')
    def watch_stop():
        while time.time() - started < 900 and not release.exists():
            time.sleep(.2)
        os.kill(os.getpid(), signal.SIGINT)
    watcher = threading.Thread(target=watch_stop, daemon=True)
    watcher.start()
    # Keep this process restricted to the approved hash. Existing persistent
    # path/hash allowlists are neither loaded nor modified.
    bypass_runtime.load_persistent_config = lambda: {'paths': [], 'cdhashes': []}
    bypass_runtime.config_modified_time_state = lambda: (None, None)
    try:
        record['state'] = 'running'
        state.write_text(json.dumps(record, indent=2) + '\n')
        bypass_runtime.run_bypass(paths=[], cdhashes=[CDHASH], verbose=True,
                                  allow_all=False, spoof_apple=True)
    finally:
        record.update(state='stopped', stoppedAt=time.time())
        state.write_text(json.dumps(record, indent=2) + '\n')
elif not sys.argv[1:]:
    log = ROOT / '.build/t51-runtime-20261021/scoped-amfidont-419d5a6c.log'
    with log.open('ab') as stream:
        process = subprocess.Popen([sys.executable, '-u', str(Path(__file__).resolve()), '--worker'],
            stdin=subprocess.DEVNULL, stdout=stream, stderr=subprocess.STDOUT,
            start_new_session=True)
    print(f'Authorized CDHash: {CDHASH}; helper PID: {process.pid}', flush=True)
else:
    raise SystemExit('Unsupported helper arguments')
