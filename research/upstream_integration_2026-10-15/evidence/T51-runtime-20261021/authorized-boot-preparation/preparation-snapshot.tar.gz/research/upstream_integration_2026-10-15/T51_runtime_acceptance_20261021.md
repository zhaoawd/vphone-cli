# T51/T52 真实磁盘与界面验收：2026-10-21

用户已批准本次具名候选的临时 AMFI 放行。`sudo -n`仍要求管理员密码，Computer Use工具拒绝操作Terminal；当前等待用户在自己的终端完成认证，helper尚未启动。用户已指示暂缓外置物理卷验收。本轮没有启动验收 VM，没有执行 guest 更新、CFW 安装或主机安全设置变更。

## 对象与结果

- 原始输入为停止的 `vm-new`。只读目录锁、lsof 和挂载检查通过后，使用 APFS clone 建立 `.build/t51rt/lib/base` 与 `target`。正在运行的 `vm-2607` 保持原 PID 33355。
- 在目标副本重写 64 MiB 相同内容，形成私有块。磁盘逻辑大小为 68,719,476,736 字节。正式 CLI 预演、rebase、交换后预演均退出0。
- published journal 报告比较25,081,413,632字节，新增共享67,108,864字节，写入和打洞均为0。交换耗时139.53秒。交换后预演新增共享0.00 GB、已有共享25.08 GB。该报告不证明系统空闲空间立即增加。
- 目标 Disk.img inode 从248260891变为248276858。目标和基准的9个具名文件完整SHA-256与原始输入一致；另1份SHSH票据摘要相同。原输入9个文件的摘要、dev/inode、大小、mtime/ctime和分配量复核保持。并未对整个约1.47万文件目录声称完整摘要验证。
- 无 `.rebase-*` 待恢复目录，published journal位于目标 `.disk-rebase-history`。此后未对目标执行启动或写入验收，故本轮没有启动后的状态摘要。
- 普通Python读进程持有目标磁盘时，CLI退出1，错误明确说明该进程不运行VM；目标磁盘inode/mtime保持。读进程由具名释放文件结束，没有向其他进程发送信号。

## 实际界面与修复

独立r1候选显示rebase操作中并禁用启动按钮。停止后两次保存的界面回归均发现目标计量长期Unknown。实际副本各有约14,707个文件，单次目录枚举约0.1秒。相同2秒计量预算下，无逐文件持有者检查映射9709文件；逐文件lsof只映射9文件，后一目录的已分配量也变为Unknown。最小回归 `mappingBudgetDoesNotMakeLaterFoldersAllocationUnknown` 首次运行有4个断言失败。

修复将元数据枚举预算与物理映射预算分开。发生实际映射时，共享目录锁覆盖该目录整次计量；持有者预检在锁内每目录一次。每个改变的文件仍复查本地状态，Disk/SEP/NVRAM映射前另行即时检查持有者。pending journal的逐文件门控保持。缓存未变时不取得该映射锁。正式回归覆盖预检期间排他锁被拒绝、逐文件后续拒绝、预算耗尽、读错误、缓存及真实APFS克隆。

r2是新建候选，r1和冻结应用均保留。r2实际界面回归结果：

| 实验设置 | 结果 | 证据 |
| --- | --- | --- |
| 停止、无人持有 | 36.9 GB已分配，8 kB独占，无缓存提示 | ui-stopped-current-r2.json |
| Python读进程持续持有 | 仍显示已停止；独占未知，显示使用上次计量结果 | ui-external-reader-r2-after-refresh.json |
| 读进程释放后 | 恢复36.9 GB/8 kB，无缓存提示 | ui-reader-released-r2.json |

计量按约30秒间隔刷新；首次持有者采样仍显示先前计量，后续刷新才进入Unknown，两个采样均保存。界面截图和辅助功能树已归档。停止状态截图 `ui-hardware-current-r2.png` 可直接查看两个计量数值。保存的 `tools/accept_t51_ui.cua.mjs` 通过cua_repl实际执行了上述断言；截图本身不替代该回归。

## 候选与主机限制

- `.build/t51-runtime-cli-20261021.app` 与 `.build/t51-runtime-launchpad-r2-20261021.app` 通过资源、native依赖、guest cohort、内嵌工具链、签名和VM权限检查。首轮资源检查拒绝旧0.8.5 API，后改用独立复制的guest目录及T08已验证0.8.6 API候选，重新生成该复制目录的cohort后通过。旧guest目录保持。
- CLI SHA-256为 `22347003fc5a6045b0c90ca3eff88ea04b7a261b5bd3ed3adac3e38772fdce00`，VM为 `4e0487e69b57f5b77db73b1085e650d87d6f998f8e3ee07c98b2573de6a553c9`；VM CDHash为 `419d5a6c67ab6328589d27246c5d09eb8cc18312`。
- 新候选与既有冻结VM程序均在 `--help` 阶段退出-9。amfid日志明确记录 Code=-424（adhoc签名包含restricted entitlements）。没有执行真正的VM启动，guest连接、正常关机、磁盘释放及运行状态界面均未验收。
- `.build/t51-runtime-20261021/scoped-amfidont.py` 已准备，固定只允许上述CDHash，不加载或修改持久名单；当前未执行。后续必须先获得本次具体授权，并在验收结束后停止具名helper。
- 外置物理磁盘枚举为空，用户明确暂缓该项。Recovery为内部卷，本轮没有用它代替外置卷。
- 冻结T60候选CLI/VM摘要保持原值。原始VM、两份验收副本及所有应用均保留，没有执行提交、推送或人审accepted。

## 命令与验证

```sh
.venv/bin/python3 research/upstream_integration_2026-10-15/tools/accept_t51_runtime.py prepare
.venv/bin/python3 research/upstream_integration_2026-10-15/tools/accept_t51_runtime.py rebase --cli .build/t51-runtime-cli-20261021.app/Contents/MacOS/vphone-cli
.venv/bin/python3 research/upstream_integration_2026-10-15/tools/accept_t51_runtime.py final-source
CLANG_MODULE_CACHE_PATH=$PWD/.build/test-module-cache SWIFT_MODULECACHE_PATH=$PWD/.build/test-module-cache swift test --disable-sandbox --filter VPhoneLaunchpadKitTests
.venv/bin/python3 -m unittest tests.test_launchpad_bundle -v
```

前三阶段退出0（prepare只接受全新目录，不能直接重复覆盖当前夹具）。定向计量9项通过；完整Kit汇总248 tests、退出0，条件跳过详日志；Python24项通过。真实计量对照使用 `VPHONE_METER_PROBE_ROOT` 和 `VPHONE_METER_PROBE_OUT` 启用保存的测试探针。正常全套测试不读取真实VM。

证据：`evidence/T51-runtime-20261021/manifest.json`。T51/T52历史status、target_review及依赖保持，accepted=false。完整崩溃矩阵、模板基准、真实外置卷与实际guest启动仍不在已通过范围内。

## 具名授权后的准备

用户明确回复“允许，仅本次具名候选”。候选完整摘要和CDHash已复核保持。helper增加900秒上限和仓库内stop-authorized-helper停止标记，不扩展允许范围、不读写持久允许名单。两次真实启动脚本verify_t51_rebase_boot.py已准备，每次guest连接后保留35秒用于界面回归；run-authorized-boots.py在结束或失败时请求helper停止。

当前未执行真实启动，未更改主机安全设置。终端命令如下；管理员密码只在用户终端输入：

```sh
sudo /usr/bin/python3 /Users/kolar/github/vphone-cli/.build/t51-runtime-20261021/scoped-amfidont.py
```

本次授权不需要重复确认。后续检测到具名helper附着成功后，可直接执行已准备的启动回归。授权/准备证据保存于evidence/T51-runtime-20261021/authorized-boot-preparation/manifest.json；前一阶段manifest及快照保持历史记录。
