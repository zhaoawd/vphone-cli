@testable import VPhoneCore
import Foundation
import Testing

struct LaunchLayoutTests {
    @Test func toolchainFingerprintIncludesBothExecutables() throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: directory) }
        let cli = directory.appendingPathComponent("vphone-cli")
        let vm = directory.appendingPathComponent("vphone-vm")
        try Data("command".utf8).write(to: cli)
        #expect(throws: (any Error).self) { try VPhoneCreateDigest.toolchain(cli: cli) }
        try Data("runtime".utf8).write(to: vm)
        let original = try VPhoneCreateDigest.toolchain(cli: cli)
        try Data("runtime2".utf8).write(to: vm)
        let changed = try VPhoneCreateDigest.toolchain(cli: cli)
        #expect(original != changed)
        try Data("command2".utf8).write(to: cli)
        #expect(try VPhoneCreateDigest.toolchain(cli: cli) != changed)
    }

    @Test func pairedRuntimeAndProcessIdentity() {
        let cli = URL(fileURLWithPath: "/Applications/vPhone.app/Contents/MacOS/vphone-cli")
        #expect(VPhoneResources.vmExecutable(executable: cli).path == "/Applications/vPhone.app/Contents/MacOS/vphone-vm")
        let processes = """
        101 /Applications/vPhone.app/Contents/MacOS/vphone-vm --config /vms/a/config.plist --dfu
        102 /Applications/vPhone.app/Contents/MacOS/vphone-vm --config /vms/b/config.plist
        103 /Applications/vPhone.app/Contents/MacOS/vphone-cli vm launch a
        104 /tmp/vphone-vm-other --config /vms/a/config.plist
        """
        #expect(VPhoneBootProcessLocator.parsePIDs(processes, configPaths: ["/vms/a/config.plist"]) == [101])
    }

    @Test func resolvesArtifactPaths() {
        let layout = VPhoneLaunchLayout(projectRoot: URL(fileURLWithPath: "/proj"))
        #expect(layout.preflightScript.path == "/proj/scripts/boot_host_preflight.sh")
    }

    @Test func resolvesToolPaths() {
        let layout = VPhoneLaunchLayout(projectRoot: URL(fileURLWithPath: "/proj"))
        #expect(layout.fwPrepareScript.path == "/proj/scripts/fw_prepare.sh")
        #expect(layout.cfwInstallHostScript.path == "/proj/scripts/cfw_install_host.sh")
        #expect(layout.pmd3Bridge.path == "/proj/scripts/pymobiledevice3_bridge.py")
    }

    @Test func delegatesToResources() {
        let resources = VPhoneResources(base: URL(fileURLWithPath: "/proj"))
        let layout = VPhoneLaunchLayout(resources: resources)
        #expect(layout.fwPrepareScript.path == resources.fwPrepareScript.path)
        #expect(layout.vphoned.path == resources.vphoned.path)
    }

    @Test func parsesLsofPIDs() {
        #expect(VPhoneLsof.parsePIDs("123\n456\n123\n\n  \nnotapid\n789\n") == [123, 456, 789])
        #expect(VPhoneLsof.parsePIDs("") == [])
    }

    // MARK: - Boot process locator

    @Test func locatesBootProcessByConfigArgument() {
        let ps = """
        80577 /repo/.build/release/vphone-cli vm launch rig-baseline --headless -vv
        80612 /repo/.build/release/vphone-cli --config /Users/u/.vphone/VMs/rig-baseline/config.plist --headless
        80614 /System/Library/Frameworks/Virtualization.framework/Versions/A/XPCServices/com.apple.Virtualization.VirtualMachine.xpc/Contents/MacOS/com.apple.Virtualization.VirtualMachine
        """
        #expect(VPhoneBootProcessLocator.parsePIDs(
            ps, configPaths: ["/Users/u/.vphone/VMs/rig-baseline/config.plist"]) == [80612])
    }

    @Test func ignoresOtherBundlesAndUnrelatedProcesses() {
        let ps = """
        101 /repo/.build/release/vphone-cli --config /Users/u/.vphone/VMs/other/config.plist --headless
        102 /usr/bin/tail -f /Users/u/.vphone/VMs/rig-baseline/config.plist
        103 /bin/cat /Users/u/.vphone/VMs/rig-baseline/config.plist
        104 /repo/.build/release/vphone-cli vm config rig-baseline --show /Users/u/.vphone/VMs/rig-baseline/config.plist
        105 /repo/.build/release/vphone-cli vm stop rig-baseline
        """
        #expect(VPhoneBootProcessLocator.parsePIDs(
            ps, configPaths: ["/Users/u/.vphone/VMs/rig-baseline/config.plist"]).isEmpty)
    }

    @Test func matchesBundledAppBinaryAndEqualsForm() {
        let ps = """
        201 /Applications/vPhone.app/Contents/MacOS/vphone-cli --config /vms/a/config.plist
        202 /Applications/vPhone.app/Contents/MacOS/vphone-cli --config=/vms/a/config.plist --dfu
        """
        #expect(VPhoneBootProcessLocator.parsePIDs(ps, configPaths: ["/vms/a/config.plist"]) == [201, 202])
    }

    @Test func dedupsSortsAndSkipsMalformedLines() {
        let ps = """
        \(String(repeating: " ", count: 4))300 vphone-cli --config /vms/a/config.plist
        200 vphone-cli --config /vms/a/config.plist
        200 vphone-cli --config /vms/a/config.plist
        notapid vphone-cli --config /vms/a/config.plist
        400
        vphone-cli --config /vms/a/config.plist
        """
        #expect(VPhoneBootProcessLocator.parsePIDs(ps, configPaths: ["/vms/a/config.plist"]) == [200, 300])
        #expect(VPhoneBootProcessLocator.parsePIDs("", configPaths: ["/vms/a/config.plist"]).isEmpty)
        #expect(VPhoneBootProcessLocator.parsePIDs("200 vphone-cli --config /vms/a/config.plist",
                                                   configPaths: []).isEmpty)
    }

    @Test func matchesEitherRawOrResolvedConfigPath() throws {
        // A symlinked library root: the boot process may carry either spelling.
        let real = FileManager.default.temporaryDirectory
            .appendingPathComponent(UUID().uuidString).resolvingSymlinksInPath()
        let bundleDir = real.appendingPathComponent("rig")
        try FileManager.default.createDirectory(at: bundleDir, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: real) }
        let link = real.appendingPathComponent("link")
        try FileManager.default.createSymbolicLink(at: link, withDestinationURL: bundleDir)

        let viaLink = link.appendingPathComponent("config.plist")
        let variants = VPhoneBootProcessLocator.configPathVariants(for: viaLink)
        #expect(variants.contains(viaLink.path))
        #expect(variants.contains(bundleDir.appendingPathComponent("config.plist").path))
        #expect(VPhoneBootProcessLocator.parsePIDs(
            "700 vphone-cli --config \(bundleDir.appendingPathComponent("config.plist").path)",
            configURL: viaLink) == [700])
    }

    @Test func matchesConfigPathWithDotDotAndSymlinksButNotPrefixCollisions() throws {
        // Real host 2026-09-17: vm-2607 was launched as
        // /Users/kolar/github/autophone/../vphone-cli/vm-2607/config.plist.
        let root = FileManager.default.temporaryDirectory
            .appendingPathComponent(UUID().uuidString).resolvingSymlinksInPath()
        defer { try? FileManager.default.removeItem(at: root) }
        let fm = FileManager.default
        for dir in ["autophone", "vphone-cli/vm-2607", "vphone-cli/vm-2607-rig2"] {
            try fm.createDirectory(at: root.appendingPathComponent(dir), withIntermediateDirectories: true)
        }
        let library = root.appendingPathComponent("vphone-cli")
        let link = root.appendingPathComponent("lib-link")
        try fm.createSymbolicLink(at: link, withDestinationURL: library)
        let config = library.appendingPathComponent("vm-2607/config.plist")
        let r = root.path
        let ps = """
        901 /repo/.build/release/vphone-cli --config \(r)/autophone/../vphone-cli/vm-2607/config.plist --headless
        902 /repo/.build/release/vphone-cli --config=\(r)/lib-link/vm-2607/config.plist
        903 /repo/.build/release/vphone-cli --config \(r)/vphone-cli/./vm-2607/config.plist
        904 /repo/.build/release/vphone-cli --config \(r)/vphone-cli/vm-2607-rig2/config.plist
        905 /repo/.build/release/vphone-cli --config \(r)/autophone/../vphone-cli/vm-2607-rig2/config.plist
        906 /repo/.build/release/vphone-cli --config \(r)/vphone-cli/vm-2607/../vm-2607-rig2/config.plist
        907 /repo/.build/release/vphone-cli --config \(r)/lib-link/vm-2607-rig2/config.plist
        908 /repo/.build/release/vphone-cli --config \(r)/vphone-cli/vm-2607/config.plist.bak
        909 /repo/.build/release/vphone-cli --config vm-2607/config.plist
        910 /usr/bin/tail -f \(r)/autophone/../vphone-cli/vm-2607/config.plist
        """
        #expect(VPhoneBootProcessLocator.parsePIDs(ps, configURL: config) == [901, 902, 903])
        // The same holds when the bundle itself is named through the symlink or with `..`.
        #expect(VPhoneBootProcessLocator.parsePIDs(ps, configURL: link.appendingPathComponent("vm-2607/config.plist")) == [901, 902, 903])
        #expect(VPhoneBootProcessLocator.parsePIDs(
            ps, configURL: URL(fileURLWithPath: "\(r)/autophone/../vphone-cli/vm-2607-rig2/config.plist")) == [904, 905, 906, 907])
        // Paths that do not exist are compared after lexical standardization only.
        #expect(VPhoneBootProcessLocator.parsePIDs(
            "1 vphone-cli --config /nonexistent/x/../vm/config.plist\n2 vphone-cli --config /nonexistent/vm-2/config.plist",
            configPaths: ["/nonexistent/vm/config.plist"]) == [1])
        #expect(VPhoneBootProcessLocator.canonicalConfigPath("relative/config.plist") == "relative/config.plist")
    }

    @Test(arguments: [false, true]) func stageVphonedCopiesWhenSourceExists(less: Bool) throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(
            at: root.appendingPathComponent(".build/guest"), withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: root) }
        let name = less ? "vphoned-less" : "vphoned"
        try Data([1, 2, 3]).write(to: root.appendingPathComponent(".build/guest/\(name)"))

        let bundleDir = root.appendingPathComponent("bundle")
        try FileManager.default.createDirectory(at: bundleDir, withIntermediateDirectories: true)
        let manifest = VPhoneVirtualMachineManifest(
            cpuCount: 2, memorySize: 1024 * 1024,
            romImages: .init(avpBooter: "a", avpSEPBooter: "b"))
        let bundle = VPhoneBundle(url: bundleDir, manifest: manifest)

        let layout = VPhoneLaunchLayout(projectRoot: root)
        #expect(try layout.stageVphoned(into: bundle, less: less) == true)
        #expect(FileManager.default.fileExists(atPath: bundleDir.appendingPathComponent(".vphoned.signed").path))
        // Second call is a no-op (already identical).
        #expect(try layout.stageVphoned(into: bundle, less: less) == false)
    }

    @Test func stageVphonedReturnsFalseWhenSourceAbsent() throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: root) }
        // No .build/guest/vphoned created → source absent.
        let bundleDir = root.appendingPathComponent("bundle")
        try FileManager.default.createDirectory(at: bundleDir, withIntermediateDirectories: true)
        let manifest = VPhoneVirtualMachineManifest(
            cpuCount: 2, memorySize: 1024 * 1024, romImages: .init(avpBooter: "a", avpSEPBooter: "b"))
        let bundle = VPhoneBundle(url: bundleDir, manifest: manifest)

        #expect(try VPhoneLaunchLayout(projectRoot: root).stageVphoned(into: bundle) == false)
        #expect(!FileManager.default.fileExists(
            atPath: bundleDir.appendingPathComponent(".vphoned.signed").path))
    }

    @Test func stageVphonedOverwritesStaleDestination() throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(
            at: root.appendingPathComponent(".build/guest"), withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: root) }
        try Data([9, 9, 9, 9]).write(to: root.appendingPathComponent(".build/guest/vphoned"))

        let bundleDir = root.appendingPathComponent("bundle")
        try FileManager.default.createDirectory(at: bundleDir, withIntermediateDirectories: true)
        // Pre-populate dst with DIFFERENT bytes.
        try Data([1, 1]).write(to: bundleDir.appendingPathComponent(".vphoned.signed"))
        let manifest = VPhoneVirtualMachineManifest(
            cpuCount: 2, memorySize: 1024 * 1024, romImages: .init(avpBooter: "a", avpSEPBooter: "b"))
        let bundle = VPhoneBundle(url: bundleDir, manifest: manifest)

        #expect(try VPhoneLaunchLayout(projectRoot: root).stageVphoned(into: bundle) == true)
        let staged = try Data(contentsOf: bundleDir.appendingPathComponent(".vphoned.signed"))
        #expect(staged == Data([9, 9, 9, 9]))
    }
}

struct ProcessHolderTests {
    @Test func classifiesExecutablePaths() {
        #expect(VPhoneProcessHolder.kind(executablePath: "/a/VPhone.bundle/Contents/MacOS/vphone-vm") == .virtualMachine)
        #expect(VPhoneProcessHolder.kind(executablePath: "/System/Library/Frameworks/Virtualization.framework/Versions/A/XPCServices/com.apple.Virtualization.VirtualMachine.xpc/Contents/MacOS/com.apple.Virtualization.VirtualMachine") == .virtualizationService)
        for path in [nil, "", "/bin/tail", "/tmp/com.apple.Virtualization.VirtualMachine", "/tmp/vphone-vm-other"] {
            #expect(VPhoneProcessHolder.kind(executablePath: path) == .other)
        }
    }

    @Test func ordersAndDescribesHolders() {
        let vm = VPhoneProcessHolder(pid: 20, executablePath: "/copy/vphone-vm")
        let reader = VPhoneProcessHolder(pid: 10, executablePath: "/bin/tail")
        let unknown = VPhoneProcessHolder(pid: 30, executablePath: nil)
        let split = VPhoneProcessHolder.classify([unknown, vm, reader])
        #expect(split.machine == [vm])
        #expect(split.others == [reader, unknown])
        #expect(VPhoneProcessHolder.diskRefusal([], rerun: "retry") == nil)
        let busy = VPhoneProcessHolder.diskRefusal([reader], rerun: "retry") ?? ""
        #expect(busy.contains("10 tail"))
        #expect(busy.contains("does not run the VM"))
        let running = VPhoneProcessHolder.diskRefusal([reader, vm], rerun: "retry") ?? ""
        #expect(running.contains("VM is running"))
        #expect(running.contains("20 vphone-vm, 10 tail"))
        let error = VPhoneBundleActivityError.running(name: "alpha", holders: [reader])
        #expect(error.description.contains("10 tail"))
        #expect(error.errorDescription == error.description)
        #expect(VPhoneBundleActivityError.running(name: "alpha", holders: [vm]).description.contains("is running"))
        #expect(VPhoneBundleActivityError.running(name: "alpha", holders: []).description.contains("is running"))
    }
}
