import Darwin
import Foundation

public enum VPhoneVMLockError: Error, Equatable, CustomStringConvertible, LocalizedError {
    case unavailable(String, Int32)
    case firmwareRecoveryRequired(String)
    case cfwRecoveryRequired(String)
    case snapshotRecoveryRequired(String)

    public var errorDescription: String? { description }

    public var description: String {
        switch self {
        case let .cfwRecoveryRequired(path):
            return "Pending CFW disk transaction at \(path); inspect/recover it before using this VM"
        case let .firmwareRecoveryRequired(path):
            return "Pending firmware transaction at \(path); run patch-firmware --recover before using this VM"
        case let .snapshotRecoveryRequired(path):
            return "Pending snapshot revert at \(path); run vm snapshot revert or recover before starting this VM"
        case let .unavailable(path, code):
            return "VM lock unavailable at \(path): \(String(cString: strerror(code)))"
        }
    }
}

// MARK: - VPhoneVMLockProbe

/// Non-destructive liveness probe for a VM bundle.
///
/// `VPhoneVMLock` cannot serve as a probe: acquiring it rewrites
/// `.vphone-runtime.json` with the probing process. This takes the same
/// directory flock directly and releases it immediately, leaving the record of
/// the real holder intact.
public enum VPhoneVMLockProbe {
    /// True when some process holds the bundle directory's exclusive flock.
    public static func isLockHeld(directory: URL) -> Bool {
        let directory = directory.resolvingSymlinksInPath().standardizedFileURL
        let fd = open(directory.path, O_RDONLY | O_DIRECTORY | O_CLOEXEC)
        guard fd >= 0 else { return false }
        defer { close(fd) }
        guard flock(fd, LOCK_EX | LOCK_NB) == 0 else { return true }
        _ = flock(fd, LOCK_UN)
        return false
    }
}

// MARK: - VPhoneVMLock

/// Locks the directory inode; deleting a diagnostic/lock file cannot bypass it.
/// Hold this object for the entire operation. Child boot processes acquire their
/// own lock; ordinary subprocesses must not inherit this descriptor.
public final class VPhoneVMLock {
    let descriptor: Int32
    public let state: VPhoneVMRuntimeState

    public init(directory: URL, operation: String) throws {
        let directory = directory.resolvingSymlinksInPath().standardizedFileURL
        let fd = open(directory.path, O_RDONLY | O_DIRECTORY | O_CLOEXEC)
        guard fd >= 0 else { throw VPhoneVMLockError.unavailable(directory.path, errno) }
        do {
            guard flock(fd, LOCK_EX | LOCK_NB) == 0 else {
                throw VPhoneVMLockError.unavailable(directory.path, errno)
            }
            var pending = stat()
            let pendingPath = directory.appendingPathComponent(".firmware-transaction").path
            if operation != VPhoneVMOperation.fwPatch, operation != VPhoneVMOperation.createCheckpoint,
               lstat(pendingPath, &pending) == 0 {
                throw VPhoneVMLockError.firmwareRecoveryRequired(pendingPath)
            }
            if operation != VPhoneVMOperation.cfwRecord, operation != VPhoneVMOperation.fwReceipts,
               let pending = try FileManager.default.contentsOfDirectory(atPath: directory.path).first(where: { $0.hasPrefix(".cfw_disk.") }) {
                throw VPhoneVMLockError.cfwRecoveryRequired(directory.appendingPathComponent(pending).path)
            }
            if operation != VPhoneVMOperation.snapshot,
               let pending = try FileManager.default.contentsOfDirectory(atPath: directory.path).first(where: { name in
                   guard name.hasPrefix(".snapshot-revert-") else { return false }
                   var journal = stat()
                   let journalPath = directory.appendingPathComponent(name)
                       .appendingPathComponent(VPhoneMachineSnapshots.revertJournalFileName).path
                   return lstat(journalPath, &journal) == 0
               }) {
                throw VPhoneVMLockError.snapshotRecoveryRequired(directory.appendingPathComponent(pending).path)
            }
            var info = stat()
            guard fstat(fd, &info) == 0 else { throw VPhoneVMLockError.unavailable(directory.path, errno) }
            let record = VPhoneVMRuntimeState(
                bundleIdentifier: "\(info.st_dev):\(info.st_ino)", bundlePath: directory.path,
                pid: getpid(), instanceID: UUID().uuidString, startedAt: Date(), operation: operation)
            do {
                try record.write(in: directory)
            } catch {
                let message = "[vphone] Warning: runtime record could not be written: \(error)\n"
                FileHandle.standardError.write(Data(message.utf8))
            }
            descriptor = fd
            state = record
        } catch {
            _ = flock(fd, LOCK_UN)
            close(fd)
            throw error
        }
    }

    deinit {
        // End the lease explicitly, including transient descriptor duplicates
        // in concurrently spawned children before their close-on-exec runs.
        _ = flock(descriptor, LOCK_UN)
        close(descriptor)
    }

    /// Deletes the runtime record when this process wrote it for `operation`
    /// and no process holds the bundle lock now. The flock is taken (without
    /// waiting) for the check and the deletion, so a holder that acquires the
    /// lock afterwards writes its own record and never loses it. Returns true
    /// when the record was deleted. A record left by a process that ended
    /// without this step names an exited pid, which every reader treats as stale.
    @discardableResult
    public static func removeRecord(directory: URL, operation: String, writtenBy pid: pid_t = getpid()) -> Bool {
        let directory = directory.resolvingSymlinksInPath().standardizedFileURL
        let fd = open(directory.path, O_RDONLY | O_DIRECTORY | O_CLOEXEC)
        guard fd >= 0 else { return false }
        defer { close(fd) }
        guard flock(fd, LOCK_EX | LOCK_NB) == 0 else { return false }
        defer { _ = flock(fd, LOCK_UN) }
        guard let record = VPhoneVMRuntimeState.read(in: directory), record.pid == pid, record.operation == operation
        else { return false }
        return unlink(directory.appendingPathComponent(VPhoneVMRuntimeState.filename).path) == 0
    }
}
